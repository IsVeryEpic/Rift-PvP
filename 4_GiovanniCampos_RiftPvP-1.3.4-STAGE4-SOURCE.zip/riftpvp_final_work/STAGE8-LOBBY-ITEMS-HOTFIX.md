# RiftPvP Stage 8 hotfix — lobby item radius (Paper 26.1.2)

## Confirmed issue
`LobbyHotbar.refresh()` and `LobbyPerks.tick()` used the same 48-block
`inLobby()` radius as combat and inventory protections. Elytra, rockets,
Wind Charges and lobby menu items therefore vanished when a player flew a
short distance from spawn (and could fall because the Elytra was removed).

## Change
- New `RiftPvpPlugin.inLobbyItems(Location)` checks the **horizontal** X/Z
  distance in the configured lobby world, independent of height.
- Default temporary-item radius is **192 blocks**. Configurable as
  `lobby.items-radius` from 8 to a maximum of 225 blocks.
- LobbyHotbar, LobbyPerks and LobbyVisibility use this boundary for refresh/removal and
  teleport checks. PvP teleport departures remove items as before.
- Keep `inLobby()` (48 blocks by default) for actual lobby protection,
  inventory clearing, combat, `/kit` blocking, and other unrelated logic. The visibility spyglass now works within the wider item zone.
- Match locations must stay >=250 blocks horizontally away from the lobby;
  the maximum item radius stays below that separation.
- Roles and admin/moderator permissions are unchanged.

## Validation
Source diff checked; resource and JAR inspection planned. Without a
Paper test server this fix cannot be claimed live-tested. A bytecode-only
hotfix JAR must retain the exact original Stage 8 JAR and only replace
its three changed classes, with no modifications to unrelated classes.
