# RiftPvP v1.3.4 — Acceptance and verification plan

This document lists tests to **run**, not tests claimed to have passed. Test on an independent Paper 26.2 server with Java 25 and real player accounts before installing on the live server.

## Build
- [ ] Maven clean package using Java 25 and Paper API matching server
- [ ] JAR has valid `plugin.yml`, correct version and commands
- [ ] Server starts without warnings or missing class/version errors
- [ ] Existing v1.3.3 config/data migrated without loss
- [ ] Reload / full restart / stop leaves no orphaned tasks or entities

## Permissions (both OP and non-OP accounts)
- [ ] Non-OP can `/heal`, `/pvheal`, `/tpa`, `/tpahere`, `/tpaccept`, `/tpdeny`, `/duel`, `/party`, `/ranked`, `/settings`, `/kiteditor`, `/visibility` and appropriate public commands
- [ ] Non-OP cannot `/riftpvp` admin actions, `/kitcreate`, `/kitsettings`, `/match inspect`, impersonate staff or grant VIP
- [ ] VIP/Founder cosmetic items available without accidental admin powers

## Match placement and safety
- [ ] 2 or more simultaneous fights stay ≥250 blocks apart from each other and lobby
- [ ] All matchmaking modes reject snow, ice, frozen, powder-snow, lava, water, caves, steep/unsafe columns
- [ ] Reaching the last retry fails cleanly rather than accepting an unsafe location
- [ ] `/rtp` continues to allow snowy locations and respects prior world/cooldown rules
- [ ] Chunk loading happens asynchronously and early enough for both player arrival positions
- [ ] Two players receive kits correctly after teleport and face each other
- [ ] Countdown blocks damage and premature movement/throwing
- [ ] Teleport failures and match cancellations clear reservations and restore both players

## Teleport and chat actions
- [ ] TPA and TPA-here messages describe direction correctly
- [ ] Click accept, decline and cancel; expired clicks do nothing unsafe
- [ ] Multiple requesters cannot overwrite or accept the wrong request
- [ ] Warmup cancels on movement, damage, combat, logout and world changes
- [ ] Block teleport escape into/out of active fights
- [ ] Clickable duel, party, rematch, requeue, lobby and spectate actions validate permissions/state

## Combat, ranked and reports
- [ ] Pearl/self Wind Charge/fall/environmental damage does not start tag
- [ ] Enemy projectile or melee hit does start tag and blocks heal, kit and teleport
- [ ] Death/kill clears tags according to saved settings
- [ ] Five placements per kit, LT5→HT1 tier order and sensible Elo behavior
- [ ] Ranked quit/intentional abandon gets cooldown; server failure/failed teleport does not
- [ ] Ranked season/profile history persists across reboot
- [ ] Match IDs unique across server restart; inspect shows recorded details only
- [ ] Nearby rekit notification radius works; failed rekit attempts distinguishable from actual equips
- [ ] Player reports stored and staff access guarded

## Kit Room anti-dupe / XP
- [ ] Top preset items replenish after click and drag without leaving into real inventory
- [ ] Bottom editing inventory accepts ONLY the kit's preset items
- [ ] No multiplication exploit via shift-click, double-click, hotbar keys, offhand, cursor, drag, quit/rejoin, opening a different GUI
- [ ] Normal 64 XP bottle cap across all stacks and offhand; Endgame exempt
- [ ] HTK editor offers End Stone; no unrelated items
- [ ] Three distinct layouts per kit persist and apply in all fight types
- [ ] `/kit` unavailable in lobby, `/kiteditor` still available

## Lobby and spectators
- [ ] Fight death respawns in lobby, does not interfere with Survival worlds
- [ ] VIP/Founder get temporary Elytra + infinitely replenished Wind Charges and rockets in lobby only
- [ ] Flight equipment never survives teleport into a fight; no storage/drop exploits
- [ ] Lobby visibility modes Everyone/Party/Hidden work bidirectionally and reset outside lobby
- [ ] Spectators invisible/non-interactive to fighters, can exit safely
- [ ] Join title/chat actions appear; no forced menu on every join

## Performance / stress
- [ ] Simultaneous queues, chunk loads and reconnects do not freeze ticks
- [ ] Controlled limits on chunk tickets, active teleport searches, logs and notifications
- [ ] Data corruption tests: server restart during kit edit or fight result save

## Verification outcome
Build: **NOT RUN — Java 25/Maven/dependency unavailable in the current execution environment.**
Live tests: **NOT RUN — no accessible Paper test server or two-player session.**
Source-only static checks: recorded separately in dev-source README.

## Stage 4 regression additions (NOT YET RUN)

- [ ] Verify casual unranked duel, RTP Queue win and loss do NOT affect ranked placements/Elo; a real ranked win/loss does.
- [ ] Queue two ranked players with Elo difference exceeding the initial window: they remain queued, then become eligible after widening *without any third player joining*.
- [ ] Verify two queued rated players match exactly once; no iterator/mutation exception or orphaned queue entry.
- [ ] Confirm old clickable TPA links cannot act on a new request from the same sender.
- [ ] Admin OP with only Admin rank receives no VIP Elytra. VIP/Founder do. Explicit `riftpvp.vipflight` permission enables the perk.
- [ ] Attempt crafting grid, shift click, offhand move, hotbar swap, containers and custom recipes with VIP consumables: no item leaks beyond lobby.
- [ ] Older kit with more than 64 XP bottles opens in the Kit Room with a valid limited layout; Endgame remains uncapped. Check save/reload.
- [ ] De-opped Admin/Founder cannot be kicked or banned by Moderator; Admin can moderate Moderator; moderator cannot moderate another moderator.
- [ ] Simulate ban-file write failure: no mistaken acknowledgement or in-memory unban.
