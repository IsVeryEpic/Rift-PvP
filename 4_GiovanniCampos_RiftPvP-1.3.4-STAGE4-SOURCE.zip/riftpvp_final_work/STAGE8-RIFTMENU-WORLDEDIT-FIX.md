# RiftPvP Stage 8 — Rift Menu/WorldEdit compatibility fix (Paper 26.1.2)

- Rift Menu shortcut uses `HEART_OF_THE_SEA`, no longer `COMPASS` (conflicted with WorldEdit compass navigation and OP teleport-to-target-block behavior).
- Random TP shortcut uses `AMETHYST_SHARD`, no longer throwable `ENDER_PEARL`.
- Both GUI icons changed to non-functional decoration (no throwable/WorldEdit behavior).
- Lobby refresh replaces older marked shortcut items in assigned slots, including any previous compass and Ender Pearl items.
- Rift Menu now opens from its hotbar item via the directly registered plugin-owned menu handler on the next server tick, avoiding interference with vanilla interaction. Sneak-right-click opens the legacy RTPQ menu.
- The hub menus (RTPQ, RTP, Kit Editor, leaderboard, settings, staff, admin) use existing menu handlers after confirming permissions; no extra admin permissions are granted.
- The earlier all-death lobby respawn behavior, auto-clear, finite Wind Charges and large horizontal lobby-items radius remain in source.
- No changes to worlds or player data; test using Paper 26.1.2/Java 25 and WorldEdit on the server.
