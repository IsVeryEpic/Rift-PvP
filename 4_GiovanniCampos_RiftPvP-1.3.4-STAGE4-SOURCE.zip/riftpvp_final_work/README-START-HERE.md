# RiftPvP v1.3.4 — Stage 4 development source

This is the latest **source-only** snapshot. It contains **no compiled or tested v1.3.4 JAR**.

- Read `STAGE4-BUILD-STATUS.md` for verified changes and the blockers.
- Read `SPECIFICATION.md` and `TEST-PLAN.md` for the full release scope and necessary checks.
- The build target is Paper 26.2, Java 25. Run `./build.sh` in a compatible environment to attempt a build.
- A successful build alone does not mean the plugin passed gameplay tests. Start with a disposable Testing server, not your live Survival/PvP server.
- Keep your currently deployed v1.3.3 JAR in place until v1.3.4 passes validation.
