# RiftPvP v1.3.4 — Stage 8 development source

This archive continues from the latest **Stage 7 source** and includes six additional systems:

- Scheduled and manual backups with staged, console-only restoration
- Server-template-verified custom-kit inventories and anti-exploit restrictions
- In-fight disconnect/rejoin grace period (default 25 seconds)
- Per-kit toggles for ranked, RTP queues, duels and custom queues (`/kitmodes`)
- First-join clickable tutorial (`/tutorial`)
- Persistent maintenance mode (`/riftpvp maintenance`)

**THIS ARCHIVE IS SOURCE CODE, NOT A PLUGIN JAR.** It has not been compiled against Paper 26.1.2 with Java 25, nor tested in a live multiplayer match.

Start with `STAGE8-IMPLEMENTATION-AND-TESTS.md`, which lists commands, safeguards, test results and the remaining acceptance tests. Previous stage reports are retained for history.

To compile: extract the ZIP; build the `riftpvp_final_work/pom.xml` project using JDK 25, Maven 3.9+ and access to the Paper 26.1.2 API. The repository GitHub Actions workflow can attempt that build after the source ZIP is uploaded. **Do not put this source ZIP in the Minecraft `plugins/` directory.**

Keep a known-good plugin JAR and backup of `plugins/RiftPvP/` until a disposable Paper Testing server has passed the verification checklist. The previous Stage 4 GitHub-built JAR does not include these updates.


## Paper 26.1.2 compatibility profile (2026-10-31)

This Stage 8 source is now configured to compile against `io.papermc.paper:paper-api:26.1.2.build.74-stable` using Java 25, and its `plugin.yml` declares `api-version: 26.1`. The source remains a development snapshot until a Java 25 type-check/compile and multiplayer regression test are successful. See `PAPER-26.1.2-COMPATIBILITY.md`.
