# RiftPvP v1.3.4 — Locked feature specification

Status: **approved specification / development source draft**. This is **not an installed, compiled, or server-tested v1.3.4 release**. Baseline: v1.3.3, as supplied by the user in their ChatGPT Library. All existing working functionality and player data must be preserved. Minecraft Paper 26.2 / Java 25 remains the target unless the actual server version is confirmed otherwise.

## A. Player-facing teleport commands and clickable chat

- `/tpa <player>` requests moving requester to target; `/tpahere <player>` requests target to move to requester.
- `/tpaccept [player]`, `/tpdeny [player]`, and cancellation, with **clickable** green Accept/red Decline/Cancel chat components; show correct direction and initiator, optional hover details and 60-second expiry.
- No OP required. Enforce permission, request expiry, online status, pending/active match and combat locks **at acceptance and again at teleport**. Never allow TPA to bypass duel protection or a designated lobby/arena policy.
- Accepted TPA has 3-second movement/damage/combat-cancelled warmup. Clean up on disconnect, world change or rejection. Check destination footing before teleport. Do not teleport if either party enters combat.
- Duel challenges, party invites, rematches, requeue, spectate and lobby returns should also include clickable actions. Validate messages server-side; clicking an expired/old link must not execute an unrelated newer request.

## B. Combat and matchmaking

- Self/environmental damage, including ender pearl impact and one's own Wind Charge, must **not** start a combat tag. Enemy-caused direct/projectile damage starts/refreshes tag for both players. Existing tag must not be removed by later self damage.
- Normal `/rtp` world and biome selection remains **unchanged**, including snowy biomes.
- All *fight* teleports (ranked, unranked, duel, RTP queue) must exclude snowy, frozen, powder snow, underwater, lava, obstructed, steep or unplayable terrain. Both arrival positions must be safe, facing one another, with a clear 5-block air-spawn column and configured Slow Falling when applicable.
- Minimum **250-block horizontal separation** between active fights and at least 250 blocks from the configured lobby, including when lobby and matchmaking share a world. No fallback should violate safety or distance after exhausting retries; fail cleanly with no orphaned match state.
- Preselect and asynchronously preload all required fight chunks **before** the match countdown ends, ideally before announcing a match found. Release chunk tickets after use. Do not block the main server thread or cause runaway chunk generation; use concurrency limits, timeouts and failure recovery.
- Fight countdown protection: visible 3–2–1; no early damage, interaction or movement outside start pads before active phase. Do not let protected spectators interfere.
- Prevent third-party interference in duels; spectators are invisible/non-interactive to fighters, can move safely, switch player targets and leave to lobby with a clickable action.
- Handle deaths, disconnects, failed teleports and kit failures atomically; assign correct match result, return players to lobby, clear flags/gear and restore game mode. Auto-respawn at lobby only for RiftPvP-managed players, not unrelated Survival worlds.

## C. Ranked and profiles

- Independent Elo, placements, W/L, streak and seasonal statistics **per kit**, with an ordered LT5 → HT5 → LT4 → HT4 → LT3 → HT3 → LT2 → HT2 → LT1 → HT1 tier ladder. Tier thresholds configurable; these are **server-local ranks**, not official external PvP tiers.
- Five placement matches as a default. Show promotions/demotions, current tier, Elo, win rate, `/rank`, `/profile`, leaderboard and ranked profile UI.
- Ranked queue displays kit, players waiting, elapsed wait and clickable Leave Queue. Match with fair opponent selection/rating constraints; cannot fight two matches at once.
- Short, escalating penalties for *proven intentional* abandons/dodges/repeated quits, with decay/reset, staff override and server failure exemptions. A server restart, failed teleport, disconnection before fight starts, or plugin error must not automatically be judged an intentional abandon.
- Anti-boosting for repeated suspicious pairings; log evidence rather than automatically banning from weak signals.

## D. Kit Editor / Kit Room (GUI, **not a physical room**)

- Existing `/kiteditor` UI includes **Edit Layout** and **Kit Room**. The Kit Room has a **preset-only restocking top inventory** and the player's **editable bottom inventory**. Taking/dragging an allowed item into the bottom inventory automatically restores the top slot. It must not copy items from outside the preset, even using creative-style click tricks.
- Players can add approved quantities, reposition items, fill slots, use up to **three independent presets per kit**, save or reset to default. Apply the saved complete inventory, hotbar, armor and offhand preferences whenever that kit is equipped in any fight mode.
- Restrict all input actions (mouse drag, shift click, double click, hotbar numbers, offhand swap, cursor close, inventory open/quit, creative packets) so items cannot be duplicated or moved into the lobby or unrelated inventories. Work on a temporary/session inventory with atomic validation on save.
- Enforce XP bottle limits across the entire kit inventory, including offhand and split stacks: **64 total by default**; Endgame **uncapped by default**; custom kits respect per-kit toggle/cap configured by OPs in the existing Kit Settings UI. No UI action may bypass caps.
- Add **End Stone to HTK's allowed Kit Room item pool**, but do not silently alter existing base kit inventory or XP rules. Preserve original kit templates; regular players cannot edit global presets.
- `/kit` **blocked in the lobby**, but `/kiteditor` **allowed in the lobby**; outside the lobby `/kit` continues with current combat protection.

## E. Lobby, VIP and presentation

- Joining the RiftPvP server shows a stylish purple/cyan title and subtitle, restrained sounds and clickable chat navigation; should not forcibly open an inventory on every join.
- Deaths in RiftPvP fights send players to the saved lobby after respawn, clearing effects and fight gear safely. Match-related data and kit layouts persist.
- VIP and Founder get temporary **Elytra**, infinitely replenished Wind Charges and Elytra Firework Rockets **inside the lobby**. No carrying flight items into any fight; block storing, dropping or duplicating the perks. VIP privileges do not grant OP/admin commands. Founder retains VIP perks.
- Lobby visibility control: Everyone / Party-only / Hidden. A friends-only mode should appear **only if an actual friends system is implemented**; do not falsely label party-only as friends. Persist each player's choice, update when players arrive/leave and restore visibility outside lobby.
- Player `/settings` GUI includes request, duel, party, sound and notification preferences; saves across restarts.

## F. Rekit, match history and staff evidence

- Nearby kit change notifications within 48 blocks (configurable), with clear wording and optional [REPORT] clickable action. A notification shows an event, **not proof of cheating**. Any kit change attempt blocked in combat should be recorded distinctly from a successful change.
- `/matchhistory` shows opponent, kit, result, duration and date; clickable previous results with armor durability and damage info. Give each match a persistent, unique match ID (across restarts).
- OP-only `/match inspect <id>` displays contestants, mode, kit, timestamp, fight world/location, outcome, teleport events, kit changes, combat events, disconnect status and report references, sourced from actual recorded data. Staff cannot query unrecorded information as if it exists. Include retention controls to prevent an unbounded log.
- `/report <player|match-id>` should store a match reference and allow reports from a nearby rekit notification, accessible to staff.
- OP-only configuration GUI for combat duration, match separation, kit XP caps, queue countdown, visibility radius, queue penalties and other documented settings; persist edits.

## G. Existing features and compatibility to preserve

- The v1.3.3 public-command permission fixes including non-OP `/heal` and `/pvheal`; OP-only admin/kit creation and settings; Founder/VIP inheritance without admin escalation.
- Existing 14 imported kits and their data; individual kit queueing; duel/rematch/party/spectator behavior; `/lobby`, three-dimension `/rtp`, NPCs, tablist, scoreboard, armor trims, healing and combat safety.
- Store plugin data under `plugins/RiftPvP/` (outside resettable world folders) and migrate earlier saved layouts/configuration without data loss.
- Server should not require any client-side mod for clickable chat UI.

## H. Explicit exclusions

1. **NO automatic arena/world block cleanup** (user's 200k × 200k world makes it unnecessary).
2. **NO arena selection GUI or dedicated arena requirement** (no arenas yet; use safe random fight locations).
3. **NO Kit Editor undo feature** (not among the final user-selected additions).
4. No separate physical Kit Room. It is an integrated GUI in the existing Kit Editor.
5. No changes to the normal `/rtp` biome policy.

## Latest approved additions

- Fight separation system (250+ blocks, lobby exclusion)
- Preloaded safe fight locations
- Lobby player visibility options
- Ranked queue abandon/dodge penalties, with server-error exemptions
- Staff match inspection (`/match inspect <id>`)

All five are required for completion of the full v1.3.4 release.

## Release gate

Do not label a JAR **v1.3.4 complete** until it compiles against the target Paper API, passes simulated and live two-player testing, verifies all permissions using a non-OP test account, and covers the acceptance test plan. A `-dev` or `-SNAPSHOT` source tree is not equivalent to an installable plugin.

## Newly approved final scope additions (2026-10-30)

- OP-only `/riftpvp doctor` to diagnose world, lobby, kit and data-folder setup.
- Crash/restart player state and ranked-stat recovery without item duplication or false penalties.
- OP-only toggles in the admin configuration GUI for ranked, TPA, VIP lobby flight and rekit warnings.
- Default **Moderator** rank with reduced privileges, separate from OP-required Admin and Founder commands. Only OP admins can manage ranks, kit definitions and server settings. Moderators may kick and temporarily ban non-staff players, with mandatory reasons and maximum 30-day duration.
- Persistent, automatically expiring temporary bans, with the player-visible reason, remaining duration and moderator audit trail. Higher-ranked staff cannot be banned by moderators.
- An accessible `/staff` menu and lobby hotbar staff item, exposing only permitted actions. The menu must never give a non-OP access to administration.
- These additions DO NOT remove previously agreed systems or exclusions.
