# RiftPvP 1.3.4 Stage 7 — source implementation and verification

**Release status: DEVELOPMENT SOURCE. NOT YET A VERIFIED JAR.**

This snapshot builds on the Stage 6 custom-kit, hotbar, staff, inventory, and cleanup development code. It retains the original Java packages and `plugin.yml` registrations. All plugin data stays under `plugins/RiftPvP/` rather than world folders. No existing per-player data files have been discarded.

## Features added in Stage 7

1. **Fight analytics:** damage, healing, landed player hits, approximate aerial critical-attack candidates, and longest successive-hit chain. `/fightstats` lists persistent per-kit totals. Completed match records store the per-player measurements for `/matchinfo` and OP `/match inspect`.
2. **Queue preferences:** `/queueprefs ping <any|50|100|150|200|300>` persists the maximum acceptable *opponent* ping; both players' preferences must permit a ranked, RTP queue or custom match. The existing `/settings` GUI now offers rematch invitations, queue-join notifications, and ping cycling. Crucial match-found notices remain visible even when queue-join notices are disabled. Matchmaking retries stalled compatible queues periodically.
3. **Win streaks:** per-kit current/best streaks persist across restarts, including separate ranked streak counters; shown after matches and via `/fightstats`.
4. **Spectating:** `/spectate list`, `/spectate next`, `/spectate prev`, plus the existing `/spectate <player>` and `/unspectate`. Switching fighter keeps the spectator's original return position and game mode. Existing post-match restoration is preserved.
5. **Discord webhook bridge:** optional asynchronous messages for ranked results, reports, staff actions and ranked integrity observations. Default disabled. Set `discord.enabled: true` and `discord.webhook-url` to a genuine Discord HTTPS webhook URL. Only `discord.com`/`discordapp.com` accepted, redirects disallowed, request timeouts set and mentions suppressed. Do not publish `config.yml` with a live webhook URL.
6. **Ranked anti-boosting:** configurable monitoring of repeated ranked opponents per kit within a 60-minute window. Reports suspicious high-frequency pairings to server log and optionally Discord, adds an audit event to the match record and exposes `/riftpvp integrity` to OPs. By default **no automatic bans, Elo suppression, or placement changes**; optional `ranked.integrity.suppress-repeat-elo: true` can hold Elo rewards after threshold (test before enabling).
7. **Staff audit:** bounded rotating `staff-audit.log`; records staff kicks, temp-bans and unbans, rank updates, kit create/settings/delete/restore, admin feature changes, manual entity cleanup, lobby configuration, reloads. OP-only `/riftpvp audit [1-20]` reads recent entries. This is separate from match records.
8. **Diagnostics:** expanded OP `/riftpvp doctor` reports runtime Java version, data folder, worlds, kits, analytics active sessions, cleanup configuration and whether Discord is configured. Does not expose webhook secrets.
9. **Safer cleaner:** fresh-install defaults are **mob cleanup OFF**, **30-second drop grace**, **10-second warning**, **24-block radius around players**, and **48-block lobby-protection radius**. Does not delete NPCs, pets, named mobs, villagers, mannequins or display entities. Uses loaded worlds only, and warning task cancels on reload/disable.
10. **Custom-kit queue controls:** `/customkit host <1-6> [public|party|private]`, `/customkit invite <player>`, `/customkit join <host>`; random `/customkit queue` only matches public hosts. Private and party-only hosts require appropriate invitation/party relation. Host/guest ping preference applies, and random public matching shuffles candidates.
11. **Lobby inventory recovery:** entering the configured lobby, rejoining there or respawning there clears temporary fight inventory and resets managed match/queue state before granting owned hotbar items and eligible VIP perks. It never runs when players are outside the configured RiftPvP lobby. The existing match-recovery storage is retained.

**Additional integration:** custom-kit fight-result buttons now requeue via `/customkit ...` instead of issuing invalid `/rtpq custom:...` commands. Default permissions for normal players, Moderator, Admin and OP have been retained.

## Tests completed

- Java 21 compiler parser accepted **31/31 Java files** with zero syntax diagnostics. This is syntax parsing, not type-checking.
- Previous Stage 6 static audit: **54/54** assertions passed after adjusting the expected Java file count.
- New Stage 7 integration audit: **45/45** assertions passed, including command registrations, permission defaults, config defaults, cross-component hooks and immutable rank rules.
- Both YAML files parsed with Python PyYAML; all plugin commands are registered in source and in `plugin.yml`.
- Packaged ZIP verified with Python `ZipFile.testzip()`.

## Not tested / mandatory before deployment

- Java 25 / Maven / Paper 26.2 compilation: **NOT RUN** (environment has Java 21 only, no Maven or Paper API repository access).
- Two-player gameplay, ranked pairing, combat, XP/kit security, rejoin flow, integrations with Citizens or other region-protection plugins: **NOT RUN**.
- External Discord delivery: **NOT RUN** (no configured webhook and no network access).

**Do not place this SOURCE ZIP in the server `plugins/` directory, and do not label it a production release.** Build via the repo's existing GitHub Actions workflow, then validate on a disposable Paper 26.2 Testing server with at least two accounts. Keep the existing production JAR and back up `plugins/RiftPvP/` before testing.

### Upgrade note

On an existing installation, `config.yml` is not overwritten. If an older cleanup config explicitly contains `grounded-mobs: true` and `minimum-item-age-seconds: 0`, these destructive settings remain unless **you edit them**. Use `grounded-mobs: false`, `minimum-item-age-seconds: 30`, `warning-seconds: 10`, `player-protection-radius-blocks: 24`, and `lobby-protection-radius-blocks: 48`, then `/riftpvp reload`. The new Discord bridge stays disabled unless configured and explicitly enabled.
