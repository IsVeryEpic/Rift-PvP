# RiftPvP v1.3.4 – Stage 3 source development

**Status: SOURCE ONLY. NOT A COMPILED OR SERVER-TESTED RELEASE.**

Date: 2026-10-30. Base: `4_GiovanniCampos_RiftPvP-1.3.4-CONTINUED-SOURCE.zip`.

## Newly implemented in this source stage

- **Preloaded pair spawn** in `MatchQueue.java`: match location is found and checked *before* the initial teleport countdown. Both landing positions are in the same loaded chunk; a Paper plugin chunk ticket keeps them loaded while counting down. Reservation cleanup on success, cancellation and plugin shutdown. Candidate searches reject snow/frozen biomes, unsafe drop columns, and positions within 250 horizontal blocks of the lobby, active matches, or other pending matches. Standard `/rtp` remains independent and unchanged.
- **In-fight 3–2–1 start protection**: following successful teleports, both players' horizontal movement, item use/projectile throws and damage are blocked until the fight starts. Drops/falling and rotation are allowed. Managed fighters cannot damage or be damaged by unrelated players.
- **Clickable post-fight actions** in chat and fight-results GUI: Rematch, Requeue, Lobby. Spectators get a clickable Leave Spectate control and are automatically returned to their previous location and game mode after the observed match concludes.
- **Persistent `/settings` GUI**, four toggles for incoming TPA, incoming duel, party invitation, and plugin sounds. Relevant existing event handlers respect them.
- **Crash/interruption recovery**: player UUIDs in actively started matches are recorded to a plugin-folder YAML file. On a later login/server enable, unresolved players are returned to the configured lobby and their temporary fight inventories are cleared. Completed matches clear their recovery record. Active match timeouts expire the fight and request recovery.

## Validation performed

- Java compiler's Java 21 **parser** parsed all 23 Java files with no *syntax* errors. This is NOT a type-check, compilation, Java 25 verification, or API compatibility test.
- `plugin.yml` and `config.yml` are valid YAML, with default player permissions and OP-only admin node declarations.
- Source was audited for configuration/command registration, cleanup hooks, and main feature wiring.
- The source ZIP is checked for CRC integrity.

## Blocking issues

- Build container: Java 21 only, Maven absent, Paper 26.2 API not locally cached, DNS resolution to Maven repository blocked. **No usable JAR was produced.**
- Runtime tests on Paper, particularly chunk tickets, asynchronous teleport lifecycle, Kit Room duplication protections, matchmaking, ranked, protection events, legacy worlds and server crashes, have **not** been executed.
- The v1.3.4 full specification remains larger than the implemented draft. Remaining incomplete areas include advanced ranked pairing/anti-boost validation and GUI, full staff UI, comprehensive spectator and recovery edge-case validation, plus integration and regression testing. Do not present as a complete release.

## How to build elsewhere

Requires JDK 25, Maven 3.9+, network access to the Paper repository. Run from source root:

```sh
mvn --batch-mode --no-transfer-progress clean package
```

Or create a GitHub repository with this source and run `.github/workflows/build.yml`. If it compiles, this produces an **UNTESTED development JAR**, not the validated final plugin. Fix any compiler errors and test against a disposable Paper 26.2 test server with at least two accounts before deploying.

**Keep v1.3.3 installed on your main server.**
