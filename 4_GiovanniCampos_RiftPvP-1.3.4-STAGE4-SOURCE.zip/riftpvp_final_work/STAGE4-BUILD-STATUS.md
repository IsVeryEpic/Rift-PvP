# RiftPvP v1.3.4 — Stage 4 build audit

**Date:** 2026-10-30. **Release status:** SOURCE ONLY, NOT COMPILED, NOT SERVER-TESTED.

This stage continues from `4_GiovanniCampos_RiftPvP-1.3.4-STAGE3-SOURCE.zip`. Everything from Stage 3 is retained. No v1.3.4 JAR has been built or shipped.

## Actual new source fixes

- Per-kit ranked match pairing now considers Elo proximity; configured initial Elo window widens per 15 seconds spent in the queue, with a maximum gap. A server task retries matches every five seconds even without a new queue entrant. Invalid/offline candidates are pruned. Code avoids mutating an active queue iterator when the shared match pipeline clears it.
- Only **ranked** wins and losses advance the LT5–HT1 ranked-placement totals; casual duels and RTPQ no longer advance them. Previously mixed historical totals already saved in `competitive.yml` cannot be automatically separated without historical evidence; back up the file before testing a migration.
- Clickable TPA Accept/Decline links contain request-specific UUIDs, preventing old chat buttons from acting on a new request by the same sender. Manual `/tpaccept` remains available. `PlayerMoveEvent` with null destination is handled defensively.
- VIP Elytra, rockets and wind charges are restricted to the assigned VIP/Founder/Owner roles, or explicit `riftpvp.vipflight` permission. OP by itself is no longer VIP flight permission. `riftpvp.vipflight` defaults to false.
- Temporary lobby-item protections no longer skip crafting inventory clicks, closing an obvious route to transform/store perks outside the lobby.
- Moderator can moderate ordinary members/VIPs; an OP admin can also act on Moderators. Admin/Owner/Founder rank assignments remain protected even if the account is temporarily de-opped. A failed unban file write restores in-memory bans from disk rather than silently clearing them.
- The Kit Room's Reset/default layout uses the effective 64-XP cap (Endgame exempt), even if an older source kit contains excess XP bottles. HTK End Stone catalogue remains.

## Checks actually run

- Java 21 `JavacTask.parse()` parser: **23/23 Java files parsed; 0 syntax diagnostics**. Java 21 parse does NOT check Java 25 language/API compatibility.
- `static_audit.py`: **19/19 static source/config assertions passed**. These are not gameplay tests.
- `plugin.yml` and `config.yml`: parsed as valid YAML.
- ZIP CRC test: passed after packaging.

## Release blockers

- No JDK 25, Maven executable, locally cached Paper API, or reachable Maven/Paper repositories in this container. A full Java/Paper type-check or `.jar` build cannot be performed here. No development work is claimed to have been compiled.
- No Paper 26.2 test server or second player session is available for teleport, inventory duplication, moderation, rank, or recovery integration tests.
- The full spec is larger than this implementation; advanced anti-boosting, some match evidence/kit GUI/staff interface edge cases, exhaustive spectator safeguards, and integration/regression tests are not finished or verified.

**Do NOT install this source ZIP into `plugins/`. Keep v1.3.3 in production.**

To attempt compilation on a proper build machine: install Java 25 + Maven 3.9+, ensure HTTPS access to `https://repo.papermc.io/repository/maven-public/`, then run `mvn --batch-mode clean package` in the source root. The included GitHub Actions workflow can also attempt a build after the source is uploaded to a repository. Even a successful compilation must be followed by controlled tests on a Paper 26.2 testing server before use in production.
