> **Compatibility update (31 October 2026):** The source was retargeted to Paper 26.1.2 (API build 74-stable), Java 25, and plugin API 26.1. Statements about the original 26.2 target below are preserved for historical context; see `PAPER-26.1.2-COMPATIBILITY.md` for current status.

# RiftPvP v1.3.4 — Stage 8 engineering notes

**Baseline:** the latest Stage 7 development source supplied in this conversation. **Target:** Paper 26.2, Java 25. **Release status:** updated development SOURCE ONLY. This is NOT a compiled or server-tested build. The previously compiled Stage 4 JAR does not contain these changes. No live server or two-player test was executed.

## Implemented in Stage 8

1. **Scheduled and manual backup snapshots** (`DataBackups.java`): opt-in via `backups.enabled` (default true), startup snapshot, two-hour interval, retained newest ten archives, maximum uncompressed 128 MiB by default; ZIPs saved in `plugins/RiftPvP/backups/`. Includes plugin YAML data, saved kits, layouts, ranks, statistics, match records, saved custom kits and `match-sequence.txt`. Excludes transient kit-room escrow, log files and previous backups. Does NOT include world folders. Backup ZIPs include `config.yml`, which can contain secrets: restrict filesystem access. Snapshots are performed asynchronously to avoid disk IO on the main tick thread; because some existing plugin writers aren't transactional, a scheduled snapshot taken during a write should be validated on a test server before relying on it for disaster recovery.
2. **Recovery/rollback workflow**: `/riftpvp backup list|now|restore <filename> confirm`; restore requires the **server console**, maintenance ON, and zero online players. The command first copies the chosen archive and saves a pre-restore snapshot, then *stages* the restore for the next **full server restart**. The next plugin enable validates and applies it **before** loading any cached managers. ZIP path traversal, symlinks, unsupported paths, oversize expanded payloads and excessive entries are rejected. Failed startup recovery disables the plugin rather than continuing with potentially inconsistent data. It restores the files in the backup but does **not** automatically delete newer data files absent from it (conservative overlay mode); use the pre-restore snapshot for manual recovery if necessary. Do not hot-reload after staging: fully stop and start the server.
3. **Custom-kit validation** (`CustomKitSecurity.java`, `CustomKits.java`): saved YAML inventories are considered untrusted and fully rebuilt from the currently installed *server-issued* source kit before matchmaking; both players receive cloned versions of the exact same approved snapshot. Rejects overstacking, unsafe enchant levels (unless specifically allowed), nested block-state/container items, shulker boxes, bundles, and configurable forbidden materials. Permits PDC tags only when they match the trusted original server-kit metadata, preserving server-admin custom items. Source kit XP limits remain enforced.
4. **Reconnect grace** (`MatchReconnect.java`): by default 25 seconds, configurable 5–90 seconds, and applies only to an active two-player RiftPvP fight. A disconnect freezes/protects the other fighter, blocks paused movement/damage/items, and gives the missing fighter an opportunity to rejoin the same in-memory session. On successful rejoin, returns them to the saved location and resumes when both are ready. If a contestant stays offline beyond grace, the existing forfeit handler awards the match to the other contestant and queues post-match lobby recovery for the offline player. **No Elo penalty is awarded for a plugin teleport failure**; both players are recovered safely instead. If both disconnect, do not arbitrarily choose a winner. A full JVM restart does NOT resume fights and instead uses existing `MatchRecovery` lobby cleanup. Requires live two-player tests before deployment.
5. **Per-kit mode controls** (`KitModes.java`): `/kitmodes <kit> [ranked|queue|duel|custom] [on|off]`. Available to **OP/Admin/Founder**, explicitly denied to Moderator and normal members. Modes default ON for all previously configured kits (non-breaking). Turning a mode OFF cancels that kit's affected *waiting* entries/invitations/hosts and leaves active fights unchanged. Modes are read from `kits.<kit>.modes.*` in the existing config and persisted.
6. **First-join guide** (`FirstJoinTutorial.java`): one-time clickable chat guide after login with shortcuts for matchmaking, Kit Editor, custom kits, ranked, duels, and settings, stored in `tutorial-seen.yml`. Players can rerun `/tutorial`. Disabled entirely by `tutorial.enabled: false`; no forced inventory GUI.
7. **Persistent maintenance mode** (`MaintenanceControl.java`): OP/console `/riftpvp maintenance on|off|status` (preserves all existing role restrictions). Activation clears waiting ranked, RTP, and custom queues and stops new pair creation while allowing active fights to finish. Optional `maintenance.block-new-joins: true` refuses ordinary joining players, but exempts OP/Admin/Founder at synchronous player login. A pending data restore prevents joins and turning maintenance off until the full restart. Staff actions are audited.

## Commands quick reference

```text
/riftpvp backup list
/riftpvp backup now
/riftpvp maintenance on
/riftpvp backup restore backup-YYYYMMDD-HHMMSS-SSS-manual.zip confirm  # console only, zero players
# Fully stop and restart the server to apply staged recovery.
/riftpvp maintenance off
/kitmodes endgame
/kitmodes endgame ranked off
/kitmodes htk custom on
/tutorial
```

## Source validation actually executed

- Java 21 `JavacTask.parse()` parser: **37 / 37** Java files parsed; **0** syntax diagnostics. This is **not** Java 25 compilation, Bukkit/Paper symbol checking, or runtime test.
- Existing 54 Stage 5/6 source assertions, updated only to allow additional listener types and source files: **54 / 54 passed**.
- Existing Stage 7 static assertions, updated only to permit additional source files: **45 / 45 passed**.
- New Stage 8 source/config integration assertions: **50 / 50 passed**.
- YAML parsing for `plugin.yml` and `config.yml`: PASS. Command registration set equals declared command set: PASS.
- ZIP CRC test: PASS at packaging.

### Build attempt / external limits

- `java -version`: OpenJDK 21.
- Maven executable: **not installed**.
- Target Paper API dependency and JDK 25: **not present locally**.
- An HTTPS attempt to `repo.papermc.io` failed with DNS resolution error.
- Therefore a complete Java 25/Paper compile could **not** be run here, and there is no Stage 8 JAR.

## Mandatory testing before deploying

- [ ] Maven Java 25 build in GitHub Actions (or a machine with JDK 25, Maven 3.9+ and Paper API dependency) succeeds.
- [ ] Paper 26.2 starts with existing saved kits, ranks and user data. No plugin exceptions.
- [ ] Two players: ranked/unranked/custom match, disconnect one for 10s, reconnect, verify teleport, freeze/unfreeze, kits, spectator and result persistence.
- [ ] Disconnect >25s: offline player forfeits only once and receives lobby cleanup on next join. Restart mid-fight: interrupted-match recovery works, no Elo penalties.
- [ ] Concurrent disconnect of both fighters: no arbitrary winner, no stuck match flags or stale chunk tickets.
- [ ] A teleport failure during reconnect cancels safely without falsely awarding a loss.
- [ ] `/kitmodes` four toggles block the correct new queue/duel mode; in-progress match remains intact. Verify Founder/Admin access and Moderator denial.
- [ ] Inject forged YAML item values, unsafe enchants, nested container and excessive XP into saved custom kits: all rejected; legitimate custom kits still equip identical cloned inventory for both.
- [ ] Backups: create, list, prune, snapshot real data; test staged restore to separate disposable server, check permissions and data integrity; test failed/unsafe ZIP; verify missing later files (overlay behavior).
- [ ] Maintenance: queues drain, new requests refused, active matches finish, staff exceptions and restart-required gate verified.
- [ ] Brand-new player: guide appears once; `/tutorial` reopens; no forced GUI or inventory loss.
- [ ] Existing non-OP `/heal`, `/pvheal`, all 14 imported kits, spectating, NPCs, custom queue, inventory/lobby cleanups, cleanup timer, and staff permission boundaries remain correct.

**Do not deploy this source ZIP as a plugin JAR.** Extract it and compile using Java 25 and Paper 26.2 with the included `pom.xml` / `.github/workflows/build.yml`. Even successful compilation is not proof of safe multiplayer behavior.
