# RiftPvP Stage 8 NPC click fix

Existing builder-placed lobby mannequins labelled HUB, RANKED and SPECTATE were not registered by the plugin because LobbyNpcs only supported queue, rtp, leaderboard, editor and heal, and only processed stored lobby-npc-id values.

Changes:
- Add three supported NPC actions and `/riftpvp npc create <hub|ranked|spectate>` support.
- Detect exact legacy mannequin names or nearby TextDisplay labels with `(Right-click)` and restrict discovery to the configured lobby area.
- Optional OP `/riftpvp npc bind hub|ranked|spectate` for mannequins with separate unrecognized labels. No schematic rebuild required.
- HUB opens Rift Menu, RANKED opens a kit chooser and respects ranked permissions/queue rules, SPECTATE opens an active-fighter GUI and respects existing spectator restrictions.
- Maintain listener hand-suppression, inventory click/drag cancellation, and server-side command permission checks.
- Does not change NPC skins, placement, world data or existing NPC configuration.

Validation: Java 21 parse-only check, 54 baseline static, 45 Stage7, 50 Stage8 assertions. Java 25 GitHub compile and Paper startup/in-game NPC right-click test still required before claiming production readiness.
