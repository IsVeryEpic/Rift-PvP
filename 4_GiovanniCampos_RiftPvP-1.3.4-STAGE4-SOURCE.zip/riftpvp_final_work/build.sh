#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo 'RiftPvP v1.3.4 SOURCE SNAPSHOT — INCOMPLETE; for development verification only.'
command -v mvn >/dev/null || { echo 'Maven missing.' >&2; exit 1; }
command -v javac >/dev/null || { echo 'JDK missing.' >&2; exit 1; }
major="$(javac -version 2>&1 | sed -E 's/.* ([0-9]+)(\..*)?/\1/')"
if [[ "$major" -lt 25 ]]; then
  echo "Java 25+ compiler required; found: $(javac -version 2>&1)." >&2
  exit 1
fi
mvn --batch-mode --no-transfer-progress clean package
printf 'Build created %s\n' "$PWD/target/RiftPvP-1.3.4-SNAPSHOT.jar"
printf 'WARNING: This is NOT the complete v1.3.4 release. Verify implementation and live Paper tests before deploying.\n'
