# RiftPvP 1.3.4 — Kit Room cursor and drag fix

- Fix: a normal left/right click on a Kit Room catalogue item now picks up a validated clone on the cursor. The player can place or drag that item into editable player-inventory slots below.
- Keep Shift-click as an optional quick-add into the draft inventory; catalogue remains restocking and is never depleted.
- Keep top inventory read-only, block drags into catalogue, nonstandard swaps and outside drops. Escrow preserves the real inventory during editing and restores it on close.
- Enforce the 64-XP-bottle kit cap on cursor pickup, regular lower-inventory click and lower-only drag events, where the kit is capped.
- Show updated on-screen instructions.
- Source parse and existing static integration checks passed; this is not a substitute for an in-game inventory test.
