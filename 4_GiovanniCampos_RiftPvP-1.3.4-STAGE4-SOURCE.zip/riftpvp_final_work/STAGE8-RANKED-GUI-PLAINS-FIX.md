# RiftPvP Stage 8: Ranked queue GUI and plains-only matchmaking

Target: Paper 26.1.2, Java 25.

- `/ranked` with no arguments opens a dedicated 45-slot kit selection GUI rather than silently choosing the first kit.
- Ranked GUI uses the same kit display icons and positions as RTPQ, with waiting counts, per-kit rating / Elo and a leave-queue button. `/ranked <kit>` and `/ranked leave` still work.
- Rift Menu Ranked tile and Ranked NPC open the same GUI.
- Ranked matchmaking uses its own configurable biome allowlist: `ranked.allowed-biomes: [PLAINS, SUNFLOWER_PLAINS]`; all actual ranked landing positions must be in those biomes. No permissive fallback.
- Ranked candidate retry count is set separately (`ranked.location-retries`, default 20). No change to unranked queues, duels or normal `/rtp` biome policy.
- Safe destination checks, 250-block separation, async chunk preparation, air spawn and protection remain part of the shared matching pipeline.

## Manual multiplayer testing required

1. Click Ranked NPC and Rift Menu Ranked tile, and run `/ranked`. Each must open same GUI with all available kit icons, waiting counts and Elo.
2. Have two players choose same ranked kit, confirm pairing and that BOTH landing spots have PLAINS or SUNFLOWER_PLAINS biomes, regardless of the biome in which the match was requested.
3. Verify `/ranked leave`, queue cancellation, Elo / W-L / placement updates, and kit modes restrictions.
4. In a custom map with no matching Plains biome in the search bounds, verify no fight is created at an unsafe/non-Plains location.
5. Confirm normal RTPQ, `/rtp`, and duels still permit their prior range of safe non-snow biomes.

Successful Java 25 compilation does not replace an actual multiplayer test.
