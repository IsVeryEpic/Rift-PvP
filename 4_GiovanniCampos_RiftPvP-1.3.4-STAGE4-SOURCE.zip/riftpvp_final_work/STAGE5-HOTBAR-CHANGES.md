# RiftPvP 1.3.4 — Stage 5 lobby hotbar and staff hardening

Development source update based on Stage 4. **NOT A COMPILED OR GAMEPLAY-TESTED RELEASE.**

## New default lobby hotbar

Only while in the configured lobby (`/riftpvp setlobby`), the plugin attempts to place these items in **empty** hotbar slots (numbering below is in-game 1–9):

| Slot | Item | Use | Who gets it |
|---|---|---|---|
| 1 | Compass | RTP Queue menu | Players with queue permission |
| 2 | Smithing Table | Kit Editor menu | Players with editor permission |
| 3 | Ender Pearl | Random TP dimension menu | Players with RTP permission |
| 4 | Book | Kills/Deaths/Playtime leaderboard menu | Players with leaderboard permission |
| 5 | Redstone Repeater | Player settings GUI | Players with settings permission |
| 6 | Spyglass | Lobby visibility (existing system) | Players when visibility is enabled |
| 7 | Nether Star | Staff Tools menu | Assigned Moderator or actual OP |
| 8 | Comparator | OP-only Server Feature Controls | Actual OP only |
| 9 | Firework Rockets | VIP lobby flight (existing system) | Eligible VIP / Founder / Owner |

VIP Wind Charges normally prefer slot 8, but for actual OPs prefer main-inventory slot 10 to keep Admin Controls accessible; free main-inventory slots are used when necessary. The standard `/kit` is intentionally NOT a lobby shortcut because `/kit` is blocked in the lobby by the existing design; use the Kit Editor there.

Menu shortcuts carry a plugin PDC marker. The plugin prevents dragging, dropping, ordinary clicks, offhand-swapping and death drops, and removes its marked items on world/lobby departure, logout or loss of entitlement. It does not clear unrelated inventory items or overwrite occupied slots. Item display is refreshed at login/respawn/teleport, on rank assignment and periodically (including OP changes). Existing Staff Panel items in legacy slot 9 are migrated on join and `/lobby`.

Set `lobby.hotbar-enabled: false` in `plugins/RiftPvP/config.yml` to disable the new hotbar items. Visibility and VIP flight keep their own existing toggles.

## Moderator vs admin

The existing `moderator` rank is now surfaced via a protected Staff Panel (Nether Star). To grant it as OP or server console:

```
/riftpvp rank set PlayerName moderator
```

Moderator (non-OP): Staff Panel, kick players (reason required), temporary ban up to 30 days (reason required), public match summaries. Cannot target moderator/admin/owner/founder or OP, cannot unban, cannot inspect private staff evidence, cannot change kits/ranks/feature switches. The moderator rank's `plugin-admin` value is forced to false and cannot be toggled on using `/riftpvp rank admin`.

OP admin/owner/founder: all standard shortcuts plus Staff Panel and direct Admin Controls; can manage permitted moderation and OP-only menus. Being assigned the decorative `admin` rank alone **does not** grant OP-only powers.

## Small additional hardening

- Staff GUI uses an internal inventory holder instead of only checking the inventory title.
- Staff Match Info menu suggests a public command for moderators and a protected inspect command for OPs.
- Attempted bans of offline operators are denied.
- Unbans and OP feature toggles generate audit entries in the server log.
- OP VIP flight items no longer occupy the Admin Controls slot when space permits.

## Checks performed

- `python tools/static_audit.py`: 29/29 source assertions passed.
- `java -cp /tmp/riftparse ParseCheck decompiled/dev/riftpvp`: 24/24 Java files parsed; zero syntax diagnostics using Java 21 parser.
- Full Maven/Java25/Paper API compile: **NOT RUN** (Java 25, Maven and Paper dependencies unavailable locally).
- Paper multiplayer integration / hotbar behavior: **NOT RUN**.

## To build

The original GitHub build workflow looks specifically for a source ZIP named
`4_GiovanniCampos_RiftPvP-1.3.4-STAGE4-SOURCE.zip` at repository root. Upload this updated ZIP *under that same filename* to replace the old source archive, then run the GitHub workflow. Because the source ZIP changed, the previous successful Stage 4 workflow run does not validate Stage 5.

The resulting JAR, if compiled successfully, remains a **SNAPSHOT-UNTESTED** build until tested on Paper 26.2 / Java 25 with both OP and non-OP accounts. Do not replace your live plugin until that testing passes.
