# RiftPvP Stage 8 — Rift Menu restoration + lobby item radius hotfix (Paper 26.1.2)

- Restore central purple-themed `Rift Menu` navigation, `/riftmenu` (`/riftgui` alias).
- Lobby Compass opens Rift Menu on right-click. Use the RTP Queues button in the central menu (or `/rtpq`) to queue directly.
- GUI includes queue, kit editor, custom kits, ranked, duels, RTP, leaderboards, profile, settings, visibility, tutorial, lobby, and permission-gated staff/admin menus.
- Menu inventory is read-only; actions execute **existing commands**, preserving their permission and combat checks. Admin toggle remains OP-only.
- `lobby.items-radius` defaults to 192 horizontal blocks (max 225), preserving earlier Stage 8 lobby item radius fix.
- Java 25 and Paper 26.1.2 target. Gameplay tests still required; no changes to world data or stored player kits.

- VIP/Founder Wind Charges are now finite: one stack of 64 per lobby visit; no automatic refills during the visit. Rockets continue to replenish. Temporary Wind Charges still get removed on lobby exit/combat teleport.
