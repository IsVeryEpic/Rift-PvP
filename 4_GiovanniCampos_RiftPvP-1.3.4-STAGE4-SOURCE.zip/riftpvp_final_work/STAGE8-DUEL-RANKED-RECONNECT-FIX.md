# RiftPvP v1.3.4 — duel / ranked / reconnect fix

Target: Paper 26.1.2, Java 25.

- Removed the 600-second forced expiration of genuine active fights. Fights now conclude by death, explicit lobby abandonment, grace timeout after disconnect, or server restart recovery.
- Re-enabled the 25-second reconnect grace period for existing servers via a one-time configuration migration; a player who returns in time resumes at the saved fight position.
- The opponent is protected/frozen while the fight is paused; on grace timeout the absent player forfeits and the remaining player returns to the lobby. A dual disconnect does not arbitrarily award a win.
- Prevented lobby join hooks from clearing the returning player's fight inventory before reconnect completes.
- More robust Ranked Plains location matching: probe eight directions in the loaded chunk, allow more retries, retry temporary teleport concurrency busy, and display a concrete failure reason if no safe Plains spawns are available.
- Normal RTP biomes remain untouched.

Local static validation: Java 21 syntax parser 38/38 classes; static audits 54/54, Stage 7 45/45, Stage 8 50/50. These checks do not simulate a Paper multiplayer server.
