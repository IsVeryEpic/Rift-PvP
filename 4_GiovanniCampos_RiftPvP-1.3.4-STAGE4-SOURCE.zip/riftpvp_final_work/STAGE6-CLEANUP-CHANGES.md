# RiftPvP 1.3.4 — development continuation: Ground Cleanup + custom matchmaking wiring

**Development SOURCE ONLY.** Java syntax and static structural tests do not equal a Paper build or in-game tests. Source ZIP is not a plugin JAR.

## Integrated cleaner

- Enabled by default. Runs every 60 seconds in server ticks (1200 ticks at 20 TPS), starting after the first interval.
- Uses existing `rtp.worlds.overworld`, `rtp.worlds.nether`, and `rtp.worlds.end` names by default. Can override with `cleanup.worlds` to select other loaded worlds. Does not force-load chunks or worlds.
- Removes dropped item entities, XP orbs, non-player **grounded mobs** (including unnamed farm animals), and grounded non-trident projectiles.
- Does not delete players, Citizens/Paper NPCs with common metadata or PDC tags, RiftPvP mannequins, villagers/traders, named or tamed mobs, bosses, armor stands, passengers/mounts, decorative displays, or vehicles. Entities with the scoreboard tag `cleanup-protected` are excluded.
- `cleanup.minimum-item-age-seconds` permits drop grace periods; default `0` clears all grounded drops on the next sweep.
- OP-only `/riftpvp cleanup status`, `/riftpvp cleanup preview` (dry-run), `/riftpvp cleanup now` (immediate). No public chat spam. `cleanup.log-results: true` enables periodic console reports.
- OP-only Admin Feature Controls GUI contains a cleanup enabled/disabled tile; config reload re-schedules interval.
- **IMPORTANT:** `cleanup.grounded-mobs: true` is destructive to normal animal farms and mobs touching blocks. Change to `false` if you want to keep mobs and only clean drops/XP/projectiles. Make backups before testing.

## Prior requested changes integrated into the same development snapshot

- Lobby entry/rejoin/respawn inventory clearing without touching inventories outside lobby; permanent stats preserved; menu items refreshed.
- Staff/OP hotbar tools and distinct non-OP Moderator role; OP-only feature menu.
- Kit Room enabled by default only for Endgame and HTK, with a per-kit toggle in OP/Admin/Founder kit settings. `/kitdelete <kit> confirm` archives kit; `/kitrestore <kit>` restores.
- Six custom kit slots per player with subset-of-server-kit safeguards, `/customkit save|delete|list|host|queue|leave`, plus `/duel <player> custom:<1-6>`.
- Custom match equipment uses the existing safe RTPQ duel teleport/kit pipeline. Both players receive frozen kit snapshots; snapshots are discarded after the match.

## Validation status

- Java 21 JavacTask syntax parser: 27 Java source files, zero syntax diagnostics.
- Static audit: see `STAGE6-STATIC-AUDIT.txt` for individual assertions.
- YAML parsing and ZIP CRC: checked separately.
- No JDK 25, Maven or Paper API available locally; **not compiled**. No live Paper/duel/permissions/inventory tests were run.
- Do not replace the production server's JAR until Java 25/Paper 26.2 compilation and a disposable two-player test succeed.

## Deployment

Keep this source ZIP under the workflow's expected filename `4_GiovanniCampos_RiftPvP-1.3.4-STAGE4-SOURCE.zip` at repository root. GitHub Actions extracts `riftpvp_final_work/pom.xml` and builds it. Previous green workflow runs built the earlier Stage 4 snapshot, **not these new changes**.
