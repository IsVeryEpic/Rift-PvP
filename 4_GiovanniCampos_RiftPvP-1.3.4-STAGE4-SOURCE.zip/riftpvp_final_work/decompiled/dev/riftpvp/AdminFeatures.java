package dev.riftpvp;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** OP-only feature switches. Every permission is checked on click, not just when opening. */
final class AdminFeatures implements Listener {
   private final RiftPvpPlugin plugin;
   private static final String[] PATHS = {
      "features.tpa", "features.ranked", "lobby.vip-flight-enabled",
      "features.rekit-alerts", "lobby.visibility-enabled"
   };
   private static final String[] LABELS = {
      "Player TPA Requests", "Ranked Matchmaking", "VIP Lobby Flight",
      "Nearby Kit Notifications", "Lobby Player Visibility"
   };
   private static final int[] SLOTS = {10, 11, 12, 13, 14};

   AdminFeatures(RiftPvpPlugin plugin) { this.plugin = plugin; }

   void open(Player player) {
      if (!player.isOp()) { player.sendMessage("§cAdmin feature controls require OP."); return; }
      Holder holder = new Holder();
      holder.inventory = Bukkit.createInventory(holder, 27, "§5§lRiftPvP §8| §fFeatures");
      draw(holder.inventory);
      player.openInventory(holder.inventory);
   }

   private void draw(Inventory inventory) {
      inventory.clear();
      for (int i = 0; i < PATHS.length; i++) {
         boolean enabled = plugin.getConfig().getBoolean(PATHS[i], true);
         ItemStack item = new ItemStack(enabled ? Material.LIME_DYE : Material.GRAY_DYE);
         ItemMeta meta = item.getItemMeta();
         if (meta != null) {
            meta.setDisplayName(RiftPvpPlugin.colors("&d" + LABELS[i] + " &8| " + (enabled ? "&aENABLED" : "&cDISABLED")));
            meta.setLore(List.of("§7Click to toggle. Saves immediately."));
            item.setItemMeta(meta);
         }
         inventory.setItem(SLOTS[i], item);
      }
   }

   @EventHandler public void click(InventoryClickEvent event) {
      if (!(event.getView().getTopInventory().getHolder() instanceof Holder holder)) return;
      event.setCancelled(true);
      if (!(event.getWhoClicked() instanceof Player player) || !player.isOp()) return;
      int raw = event.getRawSlot();
      for (int i = 0; i < SLOTS.length; i++) if (SLOTS[i] == raw) {
         String path = PATHS[i];
         boolean value = !plugin.getConfig().getBoolean(path, true);
         plugin.getConfig().set(path, value);
         plugin.saveConfig();
         draw(holder.inventory);
         player.sendMessage("§d" + LABELS[i] + " §7» " + (value ? "§aEnabled" : "§cDisabled"));
         return;
      }
   }

   @EventHandler public void drag(InventoryDragEvent event) {
      if (event.getView().getTopInventory().getHolder() instanceof Holder) event.setCancelled(true);
   }

   private static final class Holder implements InventoryHolder {
      Inventory inventory;
      @Override public Inventory getInventory() { return inventory; }
   }
}
