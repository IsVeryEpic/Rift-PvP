package dev.riftpvp;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/** Persistent, privacy-conscious client preferences. No OP needed. */
final class PlayerPreferences implements Listener {
   private final RiftPvpPlugin plugin;
   private final File file;
   private final YamlConfiguration settings;
   private static final List<String> OPTIONS = List.of("tpa", "duels", "parties", "sounds");
   private static final int[] SLOTS = {10, 12, 14, 16};
   private static final Material[] ICONS = {Material.ENDER_PEARL, Material.DIAMOND_SWORD, Material.TOTEM_OF_UNDYING, Material.NOTE_BLOCK};
   private static final String[] NAMES = {"Teleport Requests", "Duel Requests", "Party Invitations", "RiftPvP Sounds"};

   PlayerPreferences(RiftPvpPlugin plugin) {
      this.plugin = plugin;
      this.file = new File(plugin.getDataFolder(), "player-preferences.yml");
      this.settings = YamlConfiguration.loadConfiguration(file);
   }

   boolean allows(Player player, String option) {
      if (!OPTIONS.contains(option)) return true;
      return settings.getBoolean("players." + player.getUniqueId() + "." + option, true);
   }

   void open(Player player) {
      Holder holder = new Holder();
      holder.inventory = Bukkit.createInventory(holder, 27, "§5§lRiftPvP §8| §fSettings");
      for (int i = 0; i < OPTIONS.size(); i++) {
         boolean on = allows(player, OPTIONS.get(i));
         ItemStack icon = new ItemStack(ICONS[i]);
         ItemMeta meta = icon.getItemMeta();
         if (meta != null) {
            meta.setDisplayName("§d" + NAMES[i] + " §7- " + (on ? "§aON" : "§cOFF"));
            meta.setLore(Arrays.asList("§7Click to toggle", "§8Saved for your account"));
            icon.setItemMeta(meta);
         }
         holder.inventory.setItem(SLOTS[i], icon);
      }
      player.openInventory(holder.inventory);
   }

   @EventHandler public void onClick(InventoryClickEvent event) {
      if (!(event.getView().getTopInventory().getHolder() instanceof Holder)) return;
      event.setCancelled(true);
      if (!(event.getWhoClicked() instanceof Player player)) return;
      if (event.getClickedInventory() != event.getView().getTopInventory()) return;
      for (int i = 0; i < SLOTS.length; i++) if (event.getRawSlot() == SLOTS[i]) {
         String path = "players." + player.getUniqueId() + "." + OPTIONS.get(i);
         boolean value = !allows(player, OPTIONS.get(i));
         settings.set(path, value);
         try {
            settings.save(file);
         } catch (IOException ex) {
            plugin.getLogger().warning("Cannot save player preferences: " + ex.getMessage());
            settings.set(path, !value);
            player.sendMessage("§cYour setting could not be saved.");
            return;
         }
         Bukkit.getScheduler().runTask(plugin, () -> { if (player.isOnline()) open(player); });
         return;
      }
   }

   @EventHandler public void onDrag(InventoryDragEvent event) {
      if (event.getView().getTopInventory().getHolder() instanceof Holder) event.setCancelled(true);
   }

   private static final class Holder implements InventoryHolder {
      private Inventory inventory;
      @Override public Inventory getInventory() { return inventory; }
   }
}
