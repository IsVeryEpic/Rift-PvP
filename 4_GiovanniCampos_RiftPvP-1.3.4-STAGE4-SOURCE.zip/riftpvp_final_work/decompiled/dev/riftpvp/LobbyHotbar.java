package dev.riftpvp;

import java.util.Arrays;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/** Lobby-only, owned menu shortcuts. Never overwrites player items or grants permissions. */
final class LobbyHotbar implements Listener {
    private record Shortcut(String id, int slot, Material material, String name, String permission) {}
    private static final List<Shortcut> SHORTCUTS = List.of(
        new Shortcut("queue", 0, Material.HEART_OF_THE_SEA, "§d§lRift Menu §7(Right-click)", "riftpvp.queue"),
        new Shortcut("editor", 1, Material.SMITHING_TABLE, "§b§lKit Editor §7(Right-click)", "riftpvp.kiteditor"),
        new Shortcut("rtp", 2, Material.AMETHYST_SHARD, "§a§lRandom TP §7(Right-click)", "riftpvp.rtp"),
        new Shortcut("leaderboard", 3, Material.BOOK, "§6§lLeaderboards §7(Right-click)", "riftpvp.leaderboard"),
        new Shortcut("settings", 4, Material.REPEATER, "§e§lSettings §7(Right-click)", "riftpvp.settings"),
        new Shortcut("staff", 6, Material.NETHER_STAR, "§d§lStaff Panel §7(Right-click)", "riftpvp.staff"),
        new Shortcut("admin", 7, Material.COMPARATOR, "§c§lAdmin Controls §7(Right-click)", "riftpvp.admin")
    );
    private final RiftPvpPlugin plugin;
    private final NamespacedKey ownedKey;

    LobbyHotbar(RiftPvpPlugin plugin) {
        this.plugin = plugin;
        this.ownedKey = new NamespacedKey(plugin, "lobby_hotbar_shortcut");
    }

    private String shortcutId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(ownedKey, PersistentDataType.STRING);
    }

    private boolean ours(ItemStack item) { return shortcutId(item) != null; }

    private boolean entitled(Player player, Shortcut shortcut) {
        if (shortcut.id().equals("admin")) return player.isOp();
        if (shortcut.id().equals("staff")) return plugin.staffTools().hasStaffAccess(player);
        return plugin.ranks().hasPluginPermission(player, shortcut.permission());
    }

    private ItemStack make(Shortcut shortcut) {
        ItemStack item = new ItemStack(shortcut.material());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(shortcut.name());
        meta.setLore(Arrays.asList("§7Opens a RiftPvP menu", "§8Lobby use only"));
        meta.getPersistentDataContainer().set(ownedKey, PersistentDataType.STRING, shortcut.id());
        item.setItemMeta(meta);
        return item;
    }

    void refresh(Player player) {
        if (!player.isOnline()) return;
        if (!plugin.getConfig().getBoolean("lobby.hotbar-enabled", true)
                || plugin.adminFeatures().hidesLobbyItems(player)
                || !plugin.inLobbyItems(player.getLocation())) { remove(player); return; }
        // The Kit Room uses a temporary inventory; do not change it mid-edit.
        if (plugin.kitRoom().editing(player)) return;
        PlayerInventory inventory = player.getInventory();
        // Do not keep duplicate shortcuts, misplaced shortcuts, or staff tools
        // after a rank/OP change. This is the plugin's OWN marked inventory only.
        for (int i = 0; i < 36; i++) {
            ItemStack stack = inventory.getItem(i);
            if (!ours(stack)) continue;
            Shortcut matching = SHORTCUTS.stream().filter(s -> s.id().equals(shortcutId(stack))).findFirst().orElse(null);
            if (matching == null || matching.slot() != i || stack.getType() != matching.material() || !entitled(player, matching)) inventory.setItem(i, null);
        }
        for (Shortcut shortcut : SHORTCUTS) {
            if (!entitled(player, shortcut)) continue;
            ItemStack existing = inventory.getItem(shortcut.slot());
            if (existing == null || existing.getType().isAir()) inventory.setItem(shortcut.slot(), make(shortcut));
        }
    }

    void tick() { for (Player player : Bukkit.getOnlinePlayers()) refresh(player); }

    void remove(Player player) {
        PlayerInventory inventory = player.getInventory();
        for (int i = 0; i < 36; i++) if (ours(inventory.getItem(i))) inventory.setItem(i, null);
        if (ours(inventory.getItemInOffHand())) inventory.setItemInOffHand(null);
        if (ours(player.getItemOnCursor())) player.setItemOnCursor(null);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false) public void onInteract(PlayerInteractEvent event) {
        String id = shortcutId(event.getItem());
        if (id == null) return;
        event.setCancelled(true);
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player player = event.getPlayer();
        if (plugin.adminFeatures().hidesLobbyItems(player)
                || !plugin.inLobbyItems(player.getLocation())) { remove(player); return; }
        Shortcut shortcut = SHORTCUTS.stream().filter(s -> s.id().equals(id)).findFirst().orElse(null);
        if (shortcut == null || !entitled(player, shortcut)) { refresh(player); return; }
        switch (id) {
            case "queue" -> Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline() || !plugin.inLobbyItems(player.getLocation())
                    || !plugin.ranks().hasPluginPermission(player, "riftpvp.queue")) return;
                if (player.isSneaking()) plugin.menus().openQueue(player);
                else plugin.riftMenu().open(player);
            });
            case "editor" -> plugin.menus().openEditorSelection(player);
            case "rtp" -> plugin.menus().openRtp(player);
            case "leaderboard" -> plugin.menus().openLeaderboard(player);
            case "settings" -> plugin.playerPreferences().open(player);
            case "staff" -> plugin.staffTools().open(player);
            case "admin" -> plugin.adminFeatures().open(player);
            default -> { }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST) public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        boolean hotbarSwap = event.getHotbarButton() >= 0 && event.getHotbarButton() < 9
            && ours(player.getInventory().getItem(event.getHotbarButton()));
        if (ours(event.getCurrentItem()) || ours(event.getCursor()) || hotbarSwap
                || (event.getClick() == org.bukkit.event.inventory.ClickType.SWAP_OFFHAND
                    && ours(player.getInventory().getItemInOffHand()))) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST) public void onDrag(InventoryDragEvent event) {
        if (ours(event.getOldCursor())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST) public void onSwap(PlayerSwapHandItemsEvent event) {
        if (ours(event.getMainHandItem()) || ours(event.getOffHandItem())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST) public void onDrop(PlayerDropItemEvent event) {
        if (ours(event.getItemDrop().getItemStack())) event.setCancelled(true);
    }

    @EventHandler public void onDeath(PlayerDeathEvent event) {
        event.getDrops().removeIf(this::ours);
    }

    private void soon(Player player) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> { if (player.isOnline()) refresh(player); }, 2L);
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) { soon(event.getPlayer()); }
    @EventHandler public void onRespawn(PlayerRespawnEvent event) { soon(event.getPlayer()); }
    @EventHandler public void onChangedWorld(PlayerChangedWorldEvent event) { soon(event.getPlayer()); }
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        if (!plugin.inLobbyItems(event.getTo())) remove(event.getPlayer());
        else soon(event.getPlayer());
    }
    @EventHandler public void onQuit(PlayerQuitEvent event) { remove(event.getPlayer()); }
}
