#!/usr/bin/env python3
"""Static integrity checks only; NOT a Paper compilation or Minecraft test."""
from pathlib import Path
from zipfile import ZipFile
import re, yaml, subprocess
root = Path(__file__).resolve().parents[1]
config = yaml.safe_load((root/'decompiled/config.yml').read_text())
plugin = yaml.safe_load((root/'decompiled/plugin.yml').read_text())
java = (root/'decompiled/dev/riftpvp')
main = (java/'RiftPvpPlugin.java').read_text()
practice = (java/'PracticeFeatures.java').read_text()
kit = (java/'KitRoom.java').read_text()
staff = (java/'StaffTools.java').read_text()
tpa = (java/'TeleportRequests.java').read_text()
perks = (java/'LobbyPerks.java').read_text()
checks = {
  'all registered commands declared': all(name in plugin['commands'] for name in re.findall(r'"([a-z]+)"', main.split('for (String var5 : List.of(',1)[1].split(')) {',1)[0])),
  'tpa nonOP': plugin['permissions']['riftpvp.tpa']['default'] is True,
  'admin OP only': plugin['permissions']['riftpvp.admin']['default']=='op',
  'kit creation OP only': plugin['permissions']['riftpvp.kitcreate']['default']=='op',
  'VIP flight false by default': plugin['permissions']['riftpvp.vipflight']['default'] is False,
  'ranked Elo gaps configurable': config['ranked']['matchmaking']['maximum-elo-gap'] >= config['ranked']['matchmaking']['initial-elo-gap'],
  'ranked queue periodically rescanned': 'this.practice::retryRankedMatches' in main and 'void retryRankedMatches()' in practice,
  'casual matches never award ranked W/L': 'if (fight.competitive) {\n         rating(winner' in practice,
  'kit room caps default XP': 'private ItemStack[] defaultKitItems(String kit)' in kit,
  'Kit Room HTK End Stone': 'Material.END_STONE' in kit,
  'Endgame unlimited XP rule': '"endgame".equalsIgnoreCase(kit)' in (java/'KitManager.java').read_text(),
  'TPA request-bound actions': 'req.token().toString().equals(args[1])' in tpa,
  'VIP restricted to VIP role or node': 'hasVipLobbyFlight' in perks,
  'no VIP crafting grid bypass': 'InventoryType.CRAFTING) return' not in perks,
  'staff hierarchy protected': 'SetOfStaff.isAdministrator(targetRank)' in staff and 'level(actor) >= 2' in staff,
  'staff ban saved outside worlds': 'temporary-bans.yml' in staff,
  'Lobby kit disabled': '/kit cannot be used in the lobby' in main,
  'normal RTP dimension handling intact': 'void randomTeleport(Player' in main,
  'match recovery enabled': 'this.matchRecovery.recoverOnline()' in main,
}
for k,ok in checks.items():print(('PASS' if ok else 'FAIL')+' '+k)
assert all(checks.values()), 'Static audit failed'
assert len(list(java.glob('*.java'))) == 23
print(f'PASS {len(checks)} static assertions; 23 Java files present')
