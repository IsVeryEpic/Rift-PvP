#!/usr/bin/env python3
"""Source-level checks for the Kit Room click/drag regression. Not a live Paper test."""
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'decompiled/dev/riftpvp/KitRoom.java').read_text()
checks={
 'plain click produces cursor item': 'player.setItemOnCursor(copy);' in s,
 'quick add available': 'ClickType.SHIFT_LEFT || click == ClickType.SHIFT_RIGHT' in s,
 'quick add writes draft storage': 'player.getInventory().addItem(copy)' in s,
 'catalogue click always cancelled': 'event.setCancelled(true);' in s and 'if (event.getRawSlot() < 45)' in s,
 'lower normal clicks enabled': 'event.setCancelled(false);' in s,
 'lower inventory drags allowed': 'event.getRawSlots().stream().anyMatch(i -> i < 54)' in s,
 'cursor kit item validation': 'allowed(session.kit, event.getCursor())' in s,
 'drag cursor validation': 'allowed(session.kit, cursor)' in s,
 'XP cap on cursor movement': 'KitManager.countXpBottles(snapshot(player)) + cursor.getAmount() > 64' in s,
 'drag catalog protection': 'event.getRawSlots().stream().anyMatch(i -> i < 54)' in s,
 'restore real inventory': 'restore(player, session.original);' in s,
 'do not drop edited item': 'onDrop(PlayerDropItemEvent event)' in s,
}
for name,ok in checks.items():print(('PASS' if ok else 'FAIL')+' '+name)
if not all(checks.values()):raise SystemExit(1)
print('Passed',len(checks),'source-level Kit Room checks')
