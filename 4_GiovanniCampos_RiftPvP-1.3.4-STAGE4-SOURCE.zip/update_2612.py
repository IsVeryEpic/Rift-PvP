from pathlib import Path
from datetime import date
import xml.etree.ElementTree as ET
import re
root=Path('/mnt/data/rift_stage8_2612/riftpvp_final_work')
pom=root/'pom.xml'; s=pom.read_text(); old='26.2.build.129-stable'; new='26.1.2.build.74-stable'
assert s.count(old)==1
s=s.replace(old,new)
pom.write_text(s)
plugin=root/'decompiled/plugin.yml'; s=plugin.read_text(); assert "api-version: '1.21.11'" in s; s=s.replace("api-version: '1.21.11'", "api-version: '26.1'")
plugin.write_text(s)
readme=root/'README-START-HERE.md'
s=readme.read_text(); s=re.sub(r'Paper 26\.2', 'Paper 26.1.2', s);s=s.replace('the Paper 26.2 API','the Paper 26.1.2 API')
s+='\n\n## Paper 26.1.2 compatibility profile (2026-10-31)\n\nThis Stage 8 source is now configured to compile against `io.papermc.paper:paper-api:26.1.2.build.74-stable` using Java 25, and its `plugin.yml` declares `api-version: 26.1`. The source remains a development snapshot until a Java 25 type-check/compile and multiplayer regression test are successful. See `PAPER-26.1.2-COMPATIBILITY.md`.\n'
readme.write_text(s)
report=root/'STAGE8-IMPLEMENTATION-AND-TESTS.md';s=report.read_text();s='> **Compatibility update (31 October 2026):** The source was retargeted to Paper 26.1.2 (API build 74-stable), Java 25, and plugin API 26.1. Statements about the original 26.2 target below are preserved for historical context; see `PAPER-26.1.2-COMPATIBILITY.md` for current status.\n\n'+s;report.write_text(s)
compat='''# RiftPvP v1.3.4 Stage 8 — Paper 26.1.2 compatibility update

## Supported target
- Minecraft server: Paper 26.1.2, ideally release build 74.
- Java: JDK 25 for compiling and JRE/JDK 25 for runtime.
- Maven Paper API: `io.papermc.paper:paper-api:26.1.2.build.74-stable` (scope `provided`).
- Bukkit plugin API declaration: `api-version: '26.1'`.
- Plugin version: `1.3.4-SNAPSHOT` (the full Stage 8 functionality remains intact in source).

## Edits applied
1. Set `pom.xml` to the Paper 26.1.2 build 74 stable API.
2. Set `decompiled/plugin.yml` API version to 26.1; do not use 26.2 here, as older servers reject newer API declarations.
3. Retain Java 25 compiler release and preserve all Stage 8 Java classes, kit data, config defaults, commands, and permissions.
4. Provide `build.sh`, `pom.xml` and `.github/workflows/build.yml` for building after extraction; `RiftPvP-1.3.4-SNAPSHOT.jar` is the expected Maven output.

## Verification limitations
- This change is based on Paper's published API artifact and source-level checks. It has **not** passed a full Java 25 Maven type-check in the current offline environment (Java 21 only, Maven unavailable, Paper API repository inaccessible).
- Source parser checks do not validate API method symbols, linkage, null handling, or runtime behavior.
- A compatible JAR is **not** included; no previous Stage 4 JAR should be represented as Stage 8.

## Build instructions
Extract the ZIP, enter the `riftpvp_final_work` directory and run:
```
java -version    # must print 25+
mvn --batch-mode --no-transfer-progress clean package
```
Take `target/RiftPvP-1.3.4-SNAPSHOT.jar`. Alternatively, upload this entire ZIP to GitHub using the original root filename `4_GiovanniCampos_RiftPvP-1.3.4-STAGE4-SOURCE.zip` and allow the repository's existing `Build RiftPvP 1.3.4` workflow to compile it. Verify the workflow used this new ZIP rather than its old Stage 4 contents.

## Mandatory Paper 26.1.2 smoke test (disposable server)
1. Save an existing plugin-data backup and keep the previous working JAR separately.
2. Check startup (`/plugins`, `/version`, no `NoSuchMethodError`, `NoClassDefFoundError`, `Unsupported API version` or `InvalidPluginException`).
3. Use a non-OP account for `/heal`, `/pvheal`, queues, kit editor and TPA; make sure staff menus and admin commands remain restricted.
4. Test 2-player ranked, casual RTPQ, duel and custom-kit fights with both receiving the correct kit.
5. Test disconnect and reconnect within and after 25-second grace; check inventory cleanup and no dupes or spurious losses.
6. Test lobby teleport/rejoin, staff default hotbar loadout, VIP items and Wind Charges under any region protection.
7. Test `/kitmodes`, Kit Room only for enabled kits, six custom kits, deletion/restore, preview cleanup, maintenance and backup staging.
8. Restart test server: preserved saves/configs, no orphaned fights/queues; test staged restore on copied data.

**Do not deploy to production until compilation and two-player tests succeed.**
'''
(root/'PAPER-26.1.2-COMPATIBILITY.md').write_text(compat)
ET.parse(pom)
print('Updated Paper 26.1.2 profile; Java files unchanged')
