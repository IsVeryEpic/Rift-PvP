from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil,hashlib,xml.etree.ElementTree as ET,yaml
base=Path('/mnt/data/rift_stage8_2612'); root=base/'riftpvp_final_work'
paths=[Path('/mnt/data/4_GiovanniCampos_RiftPvP-1.3.4-STAGE8-PAPER-26.1.2-SOURCE.zip'), Path('/mnt/data/4_GiovanniCampos_RiftPvP-1.3.4-STAGE4-SOURCE.zip')]
with ZipFile(paths[0],'w',compression=ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(root.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and not f.name.endswith('.class') and 'target' not in f.parts:
   z.write(f, f.relative_to(base))
shutil.copyfile(paths[0],paths[1])
for p in paths:
 with ZipFile(p,'r') as z:
  assert z.testzip() is None
  names=z.namelist()
  assert 'riftpvp_final_work/decompiled/dev/riftpvp/DataBackups.java' in names
  assert 'riftpvp_final_work/decompiled/dev/riftpvp/MatchReconnect.java' in names
  assert 'riftpvp_final_work/decompiled/plugin.yml' in names
  assert 'riftpvp_final_work/GITHUB-ROOT-WORKFLOW-PAPER-26.1.2.yml' in names
  ptxt=z.read('riftpvp_final_work/pom.xml').decode()
  plugin=z.read('riftpvp_final_work/decompiled/plugin.yml').decode()
  assert '26.1.2.build.74-stable' in ptxt
  assert "api-version: '26.1'" in plugin
 print(p.name, 'size',p.stat().st_size,'files',len(names),'SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
